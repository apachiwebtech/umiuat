// export const BASE_URL = "http://localhost:8081/nodeapp"
// export const BASE_URL = "https://nodeapp.viggorventures.com/nodeapp"
export const BASE_URL = "https://nodeuat.viggorventures.com/nodeapp"
export const IMAGE_URL = 'https://viggorventures.com/upload';
export const VERSION = "70000"

