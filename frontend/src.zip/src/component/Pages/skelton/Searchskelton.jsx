import React from 'react'

const Searchskelton = () => {
  return (
    <div>
        <div className='search-ske'>
          <p></p>
          <p></p>
        </div>
    </div>
  )
}

export default Searchskelton