import React from 'react'

const Bannerskelton = () => {
  return (
    <div className='p-2'>
        <div className='banner-ske'>

        </div>
    </div>
  )
}

export default Bannerskelton