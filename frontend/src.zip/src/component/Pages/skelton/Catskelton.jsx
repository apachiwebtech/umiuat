import React from 'react'

const Catskelton = () => {
  return (
    <div className='p-2 r'>
        <div className='cat-ske' >
           <div className='cat-round'>

           </div>
        </div>
    </div>
  )
}

export default Catskelton