import React from 'react'

const Calculation = () => {
  return (
    <div>
        <div className='d-flex border justify-content-between p-2 rounded'>
          <div className='cal-ske'>
            <p></p>
            <p></p>
            <p></p>
            <p></p>
          </div>
          <div className='cal-ske'>
            <p></p>
            <p></p>
            <p></p>
            <p></p>
          </div>
        </div>
    </div>
  )
}

export default Calculation