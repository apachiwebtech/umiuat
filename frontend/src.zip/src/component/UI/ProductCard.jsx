import React from 'react'

const ProductCard = () => {
    return (
        <div>
            <div className='card'>
                <div>
                    <img src='' alt='' />
                </div>
                <div>
                    <h2>MARGERITA PIZZA</h2>
                    <p>VENDOR NAME</p>
                </div>
            </div>
        </div>
    )
}

export default ProductCard